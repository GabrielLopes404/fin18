import { API_CONFIG } from '../constants/api';

class APIService {
  constructor() {
    this.baseURL = API_CONFIG.BASE_URL;
    this.timeout = API_CONFIG.TIMEOUT;
  }

  async request(endpoint, options = {}) {
    let url = `${this.baseURL}${endpoint}`;
    
    if (options.params) {
      const queryString = new URLSearchParams(options.params).toString();
      url += `?${queryString}`;
    }
    
    const config = {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await fetch(url, {
        ...config,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(error.error || `HTTP ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('Request timeout');
      }
      throw error;
    }
  }

  get(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'GET' });
  }

  post(endpoint, data, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  put(endpoint, data, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  delete(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'DELETE' });
  }

  setAuthToken(token) {
    this.authToken = token;
  }

  getAuthHeaders() {
    if (!this.authToken) return {};
    return { Authorization: `Bearer ${this.authToken}` };
  }
}

export const storeAPI = {
  getAll: (params) => api.get(API_CONFIG.ENDPOINTS.STORES.LIST, { params }),
  getById: (id) => api.get(API_CONFIG.ENDPOINTS.STORES.DETAIL(id)),
  search: (query) => api.get(`${API_CONFIG.ENDPOINTS.STORES.SEARCH}?q=${query}`),
};

export const productAPI = {
  getAll: () => api.get(API_CONFIG.ENDPOINTS.PRODUCTS.LIST),
  getById: (id) => api.get(API_CONFIG.ENDPOINTS.PRODUCTS.DETAIL(id)),
  getByStore: (storeId) => api.get(API_CONFIG.ENDPOINTS.PRODUCTS.BY_STORE(storeId)),
};

export const serviceAPI = {
  getAll: () => api.get(API_CONFIG.ENDPOINTS.SERVICES.LIST),
  getById: (id) => api.get(API_CONFIG.ENDPOINTS.SERVICES.DETAIL(id)),
  getByStore: (storeId) => api.get(API_CONFIG.ENDPOINTS.SERVICES.BY_STORE(storeId)),
};

export const authAPI = {
  login: (credentials) => api.post(API_CONFIG.ENDPOINTS.AUTH.LOGIN, credentials),
  signup: (userData) => api.post(API_CONFIG.ENDPOINTS.AUTH.SIGNUP, userData),
  forgotPassword: (email) => api.post(API_CONFIG.ENDPOINTS.AUTH.FORGOT_PASSWORD, { email }),
};

export const cartAPI = {
  get: () => api.get(API_CONFIG.ENDPOINTS.CART.GET, { headers: api.getAuthHeaders() }),
  add: (productId, quantity) => 
    api.post(API_CONFIG.ENDPOINTS.CART.ADD, { productId, quantity }, { headers: api.getAuthHeaders() }),
  update: (itemId, quantity) => 
    api.put(API_CONFIG.ENDPOINTS.CART.UPDATE(itemId), { quantity }, { headers: api.getAuthHeaders() }),
  remove: (itemId) => 
    api.delete(API_CONFIG.ENDPOINTS.CART.DELETE(itemId), { headers: api.getAuthHeaders() }),
  clear: () => 
    api.delete(API_CONFIG.ENDPOINTS.CART.CLEAR, { headers: api.getAuthHeaders() }),
};

export const orderAPI = {
  getAll: () => api.get(API_CONFIG.ENDPOINTS.ORDERS.LIST, { headers: api.getAuthHeaders() }),
  getById: (id) => api.get(API_CONFIG.ENDPOINTS.ORDERS.DETAIL(id), { headers: api.getAuthHeaders() }),
  create: (orderData) => api.post(API_CONFIG.ENDPOINTS.ORDERS.CREATE, orderData, { headers: api.getAuthHeaders() }),
};

export const api = new APIService();
export default api;

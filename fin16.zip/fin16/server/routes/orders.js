const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { status, limit = 50, offset = 0 } = req.query;

    let query = `
      SELECT 
        o.*,
        s.name as store_name,
        s.image_url as store_image,
        json_agg(
          json_build_object(
            'id', oi.id,
            'name', oi.name,
            'quantity', oi.quantity,
            'unit_price', oi.unit_price,
            'subtotal', oi.subtotal
          )
        ) as items
      FROM orders o
      LEFT JOIN stores s ON o.store_id = s.id
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE o.user_id = $1
    `;
    
    const params = [userId];
    let paramCount = 2;

    if (status) {
      query += ` AND o.status = $${paramCount}`;
      params.push(status);
      paramCount++;
    }

    query += ` 
      GROUP BY o.id, s.name, s.image_url
      ORDER BY o.created_at DESC 
      LIMIT $${paramCount} OFFSET $${paramCount + 1}
    `;
    params.push(limit, offset);

    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Erro ao buscar pedidos' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;

    const orderResult = await db.query(
      `SELECT 
        o.*,
        s.name as store_name,
        s.image_url as store_image,
        s.phone as store_phone,
        a.street, a.number, a.complement, a.neighborhood, a.city, a.state, a.zip_code
      FROM orders o
      LEFT JOIN stores s ON o.store_id = s.id
      LEFT JOIN addresses a ON o.address_id = a.id
      WHERE o.id = $1 AND o.user_id = $2`,
      [id, userId]
    );

    if (orderResult.rows.length === 0) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }

    const itemsResult = await db.query(
      `SELECT * FROM order_items WHERE order_id = $1`,
      [id]
    );

    const trackingResult = await db.query(
      `SELECT * FROM order_tracking WHERE order_id = $1 ORDER BY created_at ASC`,
      [id]
    );

    const order = {
      ...orderResult.rows[0],
      items: itemsResult.rows,
      tracking: trackingResult.rows
    };

    res.json(order);
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ error: 'Erro ao buscar pedido' });
  }
});

router.post('/', async (req, res) => {
  const client = await db.getClient();
  
  try {
    await client.query('BEGIN');

    const userId = req.user.userId;
    const {
      store_id,
      address_id,
      payment_method_id,
      coupon_code,
      notes
    } = req.body;

    const cartResult = await client.query(
      `SELECT ci.*, p.name, p.price
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       WHERE ci.user_id = $1 AND p.store_id = $2`,
      [userId, store_id]
    );

    if (cartResult.rows.length === 0) {
      throw new Error('Carrinho vazio para esta loja');
    }

    const storeResult = await client.query(
      'SELECT delivery_fee FROM stores WHERE id = $1',
      [store_id]
    );

    const subtotal = cartResult.rows.reduce(
      (sum, item) => sum + (item.price * item.quantity),
      0
    );
    const deliveryFee = storeResult.rows[0].delivery_fee;
    let discount = 0;

    if (coupon_code) {
      const couponResult = await client.query(
        `SELECT * FROM coupons 
         WHERE code = $1 
         AND is_active = true 
         AND (valid_from IS NULL OR valid_from <= NOW())
         AND (valid_until IS NULL OR valid_until >= NOW())
         AND (usage_limit IS NULL OR times_used < usage_limit)`,
        [coupon_code]
      );

      if (couponResult.rows.length > 0) {
        const coupon = couponResult.rows[0];
        if (coupon.discount_type === 'percentage') {
          discount = (subtotal * coupon.discount_value) / 100;
          if (coupon.max_discount_amount) {
            discount = Math.min(discount, coupon.max_discount_amount);
          }
        } else {
          discount = coupon.discount_value;
        }
      }
    }

    const total = subtotal + deliveryFee - discount;

    const orderResult = await client.query(
      `INSERT INTO orders (
        user_id, store_id, address_id, payment_method_id,
        subtotal, delivery_fee, discount, total, coupon_code, notes, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'pending')
      RETURNING *`,
      [userId, store_id, address_id, payment_method_id, subtotal, deliveryFee, discount, total, coupon_code, notes]
    );

    const order = orderResult.rows[0];

    for (const item of cartResult.rows) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, name, quantity, unit_price, subtotal)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [order.id, item.product_id, item.name, item.quantity, item.price, item.price * item.quantity]
      );
    }

    await client.query(
      `INSERT INTO order_tracking (order_id, status, description)
       VALUES ($1, 'pending', 'Pedido recebido e aguardando confirmação')`,
      [order.id]
    );

    await client.query(
      'DELETE FROM cart_items WHERE user_id = $1',
      [userId]
    );

    if (coupon_code) {
      await client.query(
        `UPDATE coupons SET times_used = times_used + 1 WHERE code = $1`,
        [coupon_code]
      );
    }

    await client.query('COMMIT');

    res.status(201).json(order);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating order:', error);
    res.status(500).json({ error: error.message || 'Erro ao criar pedido' });
  } finally {
    client.release();
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { calculateDistance } = require('../utils/calculateDistance');

router.get('/', async (req, res) => {
  try {
    const { 
      latitude, 
      longitude, 
      category, 
      featured, 
      search,
      limit = 50,
      offset = 0 
    } = req.query;

    let query = `
      SELECT 
        s.*,
        COALESCE(
          json_agg(
            DISTINCT jsonb_build_object('day', sh.day_of_week, 'open', sh.open_time, 'close', sh.close_time)
          ) FILTER (WHERE sh.id IS NOT NULL), 
          '[]'
        ) as hours
      FROM stores s
      LEFT JOIN store_hours sh ON s.id = sh.store_id
      WHERE 1=1
    `;
    
    const params = [];
    let paramCount = 1;

    if (category) {
      query += ` AND s.category = $${paramCount}`;
      params.push(category);
      paramCount++;
    }

    if (featured === 'true') {
      query += ` AND s.is_featured = true`;
    }

    if (search) {
      query += ` AND (s.name ILIKE $${paramCount} OR s.description ILIKE $${paramCount})`;
      params.push(`%${search}%`);
      paramCount++;
    }

    query += ` 
      GROUP BY s.id 
      ORDER BY s.is_featured DESC, s.rating DESC 
      LIMIT $${paramCount} OFFSET $${paramCount + 1}
    `;
    params.push(limit, offset);

    const result = await db.query(query, params);

    const stores = result.rows.map(store => {
      if (latitude && longitude) {
        store.distance = calculateDistance(
          parseFloat(latitude),
          parseFloat(longitude),
          store.latitude,
          store.longitude
        );
      }
      return store;
    });

    res.json(stores);
  } catch (error) {
    console.error('Error fetching stores:', error);
    res.status(500).json({ error: 'Erro ao buscar lojas' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { latitude, longitude } = req.query;

    const result = await db.query(
      `SELECT 
        s.*,
        COALESCE(
          json_agg(
            DISTINCT jsonb_build_object('day', sh.day_of_week, 'open', sh.open_time, 'close', sh.close_time)
          ) FILTER (WHERE sh.id IS NOT NULL), 
          '[]'
        ) as hours
      FROM stores s
      LEFT JOIN store_hours sh ON s.id = sh.store_id
      WHERE s.id = $1
      GROUP BY s.id`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Loja não encontrada' });
    }

    const store = result.rows[0];

    if (latitude && longitude) {
      store.distance = calculateDistance(
        parseFloat(latitude),
        parseFloat(longitude),
        store.latitude,
        store.longitude
      );
    }

    res.json(store);
  } catch (error) {
    console.error('Error fetching store:', error);
    res.status(500).json({ error: 'Erro ao buscar loja' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.get('/', async (req, res) => {
  try {
    const { store_id, limit = 20, offset = 0 } = req.query;

    if (!store_id) {
      return res.status(400).json({ error: 'store_id é obrigatório' });
    }

    const result = await db.query(
      `SELECT 
        r.*,
        u.name as user_name,
        u.avatar_url as user_avatar
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.store_id = $1
      ORDER BY r.created_at DESC
      LIMIT $2 OFFSET $3`,
      [store_id, limit, offset]
    );

    const stats = await db.query(
      `SELECT 
        COUNT(*) as total,
        ROUND(AVG(rating)::numeric, 1) as average_rating,
        COUNT(CASE WHEN rating = 5 THEN 1 END) as five_stars,
        COUNT(CASE WHEN rating = 4 THEN 1 END) as four_stars,
        COUNT(CASE WHEN rating = 3 THEN 1 END) as three_stars,
        COUNT(CASE WHEN rating = 2 THEN 1 END) as two_stars,
        COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star
      FROM reviews
      WHERE store_id = $1`,
      [store_id]
    );

    res.json({
      reviews: result.rows,
      stats: stats.rows[0]
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ error: 'Erro ao buscar avaliações' });
  }
});

router.post('/', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    const { store_id, order_id, rating, comment, images } = req.body;

    if (!store_id || !rating) {
      return res.status(400).json({ error: 'store_id e rating são obrigatórios' });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating deve ser entre 1 e 5' });
    }

    const result = await db.query(
      `INSERT INTO reviews (user_id, store_id, order_id, rating, comment, images)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [userId, store_id, order_id, rating, comment, images || []]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating review:', error);
    res.status(500).json({ error: 'Erro ao criar avaliação' });
  }
});

module.exports = router;

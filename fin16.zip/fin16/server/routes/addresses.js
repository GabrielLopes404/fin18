const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      'SELECT * FROM addresses WHERE user_id = $1 ORDER BY is_default DESC, created_at DESC',
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching addresses:', error);
    res.status(500).json({ error: 'Erro ao buscar endereços' });
  }
});

router.post('/', async (req, res) => {
  const client = await db.getClient();
  
  try {
    await client.query('BEGIN');

    const userId = req.user.userId;
    const {
      label,
      street,
      number,
      complement,
      neighborhood,
      city,
      state,
      zip_code,
      latitude,
      longitude,
      is_default
    } = req.body;

    if (is_default) {
      await client.query(
        'UPDATE addresses SET is_default = false WHERE user_id = $1',
        [userId]
      );
    }

    const result = await client.query(
      `INSERT INTO addresses (
        user_id, label, street, number, complement, neighborhood,
        city, state, zip_code, latitude, longitude, is_default
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *`,
      [userId, label, street, number, complement, neighborhood, city, state, zip_code, latitude, longitude, is_default]
    );

    await client.query('COMMIT');

    res.status(201).json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating address:', error);
    res.status(500).json({ error: 'Erro ao criar endereço' });
  } finally {
    client.release();
  }
});

router.patch('/:id', async (req, res) => {
  const client = await db.getClient();
  
  try {
    await client.query('BEGIN');

    const userId = req.user.userId;
    const { id } = req.params;
    const { is_default, ...updateFields } = req.body;

    if (is_default) {
      await client.query(
        'UPDATE addresses SET is_default = false WHERE user_id = $1',
        [userId]
      );
    }

    const fields = [];
    const values = [];
    let paramCount = 1;

    Object.entries({ ...updateFields, is_default }).forEach(([key, value]) => {
      if (value !== undefined) {
        fields.push(`${key} = $${paramCount}`);
        values.push(value);
        paramCount++;
      }
    });

    if (fields.length === 0) {
      return res.status(400).json({ error: 'Nenhum campo para atualizar' });
    }

    values.push(id, userId);

    const result = await client.query(
      `UPDATE addresses SET ${fields.join(', ')} WHERE id = $${paramCount} AND user_id = $${paramCount + 1} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Endereço não encontrado' });
    }

    await client.query('COMMIT');

    res.json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error updating address:', error);
    res.status(500).json({ error: 'Erro ao atualizar endereço' });
  } finally {
    client.release();
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM addresses WHERE id = $1 AND user_id = $2 RETURNING *',
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Endereço não encontrado' });
    }

    res.json({ message: 'Endereço removido' });
  } catch (error) {
    console.error('Error deleting address:', error);
    res.status(500).json({ error: 'Erro ao remover endereço' });
  }
});

module.exports = router;

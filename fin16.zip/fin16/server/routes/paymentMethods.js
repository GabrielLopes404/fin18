const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      'SELECT * FROM payment_methods WHERE user_id = $1 ORDER BY is_default DESC, created_at DESC',
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching payment methods:', error);
    res.status(500).json({ error: 'Erro ao buscar métodos de pagamento' });
  }
});

router.post('/', async (req, res) => {
  const client = await db.getClient();
  
  try {
    await client.query('BEGIN');

    const userId = req.user.userId;
    const {
      type,
      card_brand,
      card_last4,
      card_holder_name,
      stripe_payment_method_id,
      is_default
    } = req.body;

    if (is_default) {
      await client.query(
        'UPDATE payment_methods SET is_default = false WHERE user_id = $1',
        [userId]
      );
    }

    const result = await client.query(
      `INSERT INTO payment_methods (
        user_id, type, card_brand, card_last4, card_holder_name,
        stripe_payment_method_id, is_default
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *`,
      [userId, type, card_brand, card_last4, card_holder_name, stripe_payment_method_id, is_default]
    );

    await client.query('COMMIT');

    res.status(201).json(result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating payment method:', error);
    res.status(500).json({ error: 'Erro ao criar método de pagamento' });
  } finally {
    client.release();
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM payment_methods WHERE id = $1 AND user_id = $2 RETURNING *',
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Método de pagamento não encontrado' });
    }

    res.json({ message: 'Método de pagamento removido' });
  } catch (error) {
    console.error('Error deleting payment method:', error);
    res.status(500).json({ error: 'Erro ao remover método de pagamento' });
  }
});

module.exports = router;

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function BenefitCard({ icon, title, description, color }) {
  return (
    <View style={styles.benefitCard}>
      <View style={[styles.iconContainer, { backgroundColor: color + '15' }]}>
        <Ionicons name={icon} size={32} color={color} />
      </View>
      <View style={styles.benefitContent}>
        <Text style={styles.benefitTitle}>{title}</Text>
        <Text style={styles.benefitDescription}>{description}</Text>
      </View>
    </View>
  );
}

export default function BenefitsSection() {
  const benefits = [
    {
      icon: 'shield-checkmark',
      title: 'Totalmente Seguro',
      description: 'Pagamentos protegidos e dados criptografados',
      color: Colors.success
    },
    {
      icon: 'flash',
      title: 'Entrega Rápida',
      description: 'Receba seus produtos em até 24 horas',
      color: Colors.accent
    },
    {
      icon: 'wallet',
      title: 'Cashback',
      description: 'Ganhe pontos em cada compra realizada',
      color: Colors.primary
    },
    {
      icon: 'headset',
      title: 'Suporte 24/7',
      description: 'Estamos sempre prontos para ajudar você',
      color: Colors.rating
    },
    {
      icon: 'heart',
      title: 'Garantia de Qualidade',
      description: 'Produtos selecionados e verificados',
      color: Colors.error
    },
    {
      icon: 'ribbon',
      title: 'Programa de Fidelidade',
      description: 'Quanto mais usa, mais benefícios ganha',
      color: Colors.success
    }
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Por que escolher o PetsGo?</Text>
      <Text style={styles.subtitle}>Benefícios exclusivos para você e seu pet</Text>
      
      <View style={styles.benefitsContainer}>
        {benefits.map((benefit, index) => (
          <BenefitCard
            key={index}
            icon={benefit.icon}
            title={benefit.title}
            description={benefit.description}
            color={benefit.color}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: Spacing.xl,
  },
  benefitsContainer: {
    gap: Spacing.md,
  },
  benefitCard: {
    flexDirection: 'row',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadows.small,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  benefitContent: {
    flex: 1,
    justifyContent: 'center',
  },
  benefitTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  benefitDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 18,
  },
});

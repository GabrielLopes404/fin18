import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function ProductItem({ product, onPress, onAddToCart }) {
  return (
    <TouchableOpacity
      style={styles.productCard}
      onPress={onPress}
      activeOpacity={0.95}
    >
      <Image
        source={{ uri: product.image }}
        style={styles.productImage}
        resizeMode="cover"
      />
      
      {product.badge && (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{product.badge}</Text>
        </View>
      )}

      <TouchableOpacity
        style={styles.favoriteButton}
        onPress={(e) => {
          e.stopPropagation();
        }}
        activeOpacity={0.8}
      >
        <Ionicons name="heart-outline" size={20} color={Colors.textPrimary} />
      </TouchableOpacity>
      
      <View style={styles.productInfo}>
        <Text style={styles.category}>{product.category}</Text>
        <Text style={styles.productName} numberOfLines={2}>{product.name}</Text>
        
        <View style={styles.ratingRow}>
          <Ionicons name="star" size={14} color={Colors.rating} />
          <Text style={styles.rating}>{product.rating.toFixed(1)}</Text>
          <Text style={styles.reviews}>({product.reviews})</Text>
        </View>

        <View style={styles.priceRow}>
          <View style={styles.priceContainer}>
            {product.oldPrice && (
              <Text style={styles.oldPrice}>R$ {product.oldPrice.toFixed(2)}</Text>
            )}
            <Text style={styles.price}>R$ {product.price.toFixed(2)}</Text>
          </View>
          <TouchableOpacity
            style={styles.addButton}
            onPress={(e) => {
              e.stopPropagation();
              onAddToCart?.(product);
            }}
            activeOpacity={0.8}
          >
            <Ionicons name="add" size={20} color={Colors.textLight} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function FeaturedProductsSection({ products = [], onProductPress, onAddToCart }) {
  const defaultProducts = [
    {
      id: '1',
      name: 'Ração Premium Golden para Cães Adultos',
      category: 'Alimentação',
      price: 189.90,
      oldPrice: 249.90,
      rating: 4.8,
      reviews: 347,
      image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500',
      badge: 'Mais Vendido'
    },
    {
      id: '2',
      name: 'Brinquedo Kong Classic',
      category: 'Brinquedos',
      price: 49.90,
      rating: 4.9,
      reviews: 521,
      image: 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=500',
      badge: 'Favorito'
    },
    {
      id: '3',
      name: 'Areia Higiênica para Gatos',
      category: 'Higiene',
      price: 35.90,
      oldPrice: 45.90,
      rating: 4.7,
      reviews: 289,
      image: 'https://images.unsplash.com/photo-1561037404-61cd46aa615b?w=500',
    },
    {
      id: '4',
      name: 'Coleira GPS Inteligente',
      category: 'Tecnologia',
      price: 299.90,
      rating: 4.6,
      reviews: 156,
      image: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500',
      badge: 'Novo'
    }
  ];

  const displayProducts = products.length > 0 ? products : defaultProducts;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Produtos em Destaque</Text>
          <Text style={styles.subtitle}>Os queridinhos dos pets</Text>
        </View>
        <TouchableOpacity activeOpacity={0.8}>
          <Text style={styles.viewAll}>Ver todos</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={displayProducts}
        keyExtractor={(item) => item.id}
        numColumns={2}
        scrollEnabled={false}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <ProductItem
            product={item}
            onPress={() => onProductPress?.(item)}
            onAddToCart={onAddToCart}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  viewAll: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
    marginTop: 4,
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
  },
  row: {
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  productCard: {
    width: '48%',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.small,
  },
  productImage: {
    width: '100%',
    height: 140,
    backgroundColor: Colors.backgroundGray,
  },
  badge: {
    position: 'absolute',
    top: Spacing.sm,
    left: Spacing.sm,
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
  },
  badgeText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
  favoriteButton: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.backgroundLight,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.small,
  },
  productInfo: {
    padding: Spacing.md,
  },
  category: {
    fontSize: FontSizes.xs,
    color: Colors.primary,
    fontWeight: FontWeights.semibold,
    marginBottom: 2,
    textTransform: 'uppercase',
  },
  productName: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
    minHeight: 32,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: Spacing.sm,
  },
  rating: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  reviews: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  priceContainer: {
    flex: 1,
  },
  oldPrice: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    textDecorationLine: 'line-through',
    marginBottom: 2,
  },
  price: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.small,
  },
});
